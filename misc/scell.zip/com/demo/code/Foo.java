package com.demo.code;

public class Foo {
    public String getHello() {
        return "Hello World";
    }
}